(globalThis["TURBOPACK_CHUNK_LISTS"] || (globalThis["TURBOPACK_CHUNK_LISTS"] = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: ["static/chunks/apps_website_src_09vcm0w._.js","static/chunks/0t0b_zod_0ujgiel._.js","static/chunks/06ln_next_0m.2c3f._.js","static/chunks/0w30_drizzle-orm_0mkwks_._.js","static/chunks/node_modules__pnpm_04j.b74._.js","static/chunks/apps_website_src_app_[locale]_events_[id]_slideshow_slideshow_module_0m57yfx.css"],
    source: "dynamic"
});
