(globalThis["TURBOPACK_CHUNK_LISTS"] || (globalThis["TURBOPACK_CHUNK_LISTS"] = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: ["static/chunks/apps_website_src_app_[locale]_join_[code]_nickname_module_0w~jsk6.css","static/chunks/apps_website_src_027hp~y._.js","static/chunks/06ln_next_12a03vu._.js","static/chunks/0t0b_zod_0ujgiel._.js","static/chunks/0w30_drizzle-orm_0mkwks_._.js","static/chunks/node_modules__pnpm_0509cca._.js"],
    source: "dynamic"
});
