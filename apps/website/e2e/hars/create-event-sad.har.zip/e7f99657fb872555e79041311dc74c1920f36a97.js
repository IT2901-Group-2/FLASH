(globalThis["TURBOPACK_CHUNK_LISTS"] || (globalThis["TURBOPACK_CHUNK_LISTS"] = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: ["static/chunks/apps_website_src_12bw4po._.js","static/chunks/node_modules__pnpm_0k_ewpt._.js","static/chunks/apps_website_src_0y27on5._.css"],
    source: "dynamic"
});
