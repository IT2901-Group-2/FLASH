(globalThis["TURBOPACK_CHUNK_LISTS"] || (globalThis["TURBOPACK_CHUNK_LISTS"] = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: ["static/chunks/[turbopack]_browser_dev_hmr-client_hmr-client_ts_12_ufbc._.js","static/chunks/06ln_next_dist_compiled_next-devtools_index_0jcwet_.js","static/chunks/06ln_next_dist_compiled_react-dom_03o00ls._.js","static/chunks/06ln_next_dist_compiled_react-server-dom-turbopack_0s9au6y._.js","static/chunks/06ln_next_dist_compiled_0eod6t4._.js","static/chunks/06ln_next_dist_client_0jzn2m3._.js","static/chunks/06ln_next_dist_0hf-3qs._.js","static/chunks/0i4a_@swc_helpers_cjs_0hvz.20._.js"],
    source: "entry"
});
