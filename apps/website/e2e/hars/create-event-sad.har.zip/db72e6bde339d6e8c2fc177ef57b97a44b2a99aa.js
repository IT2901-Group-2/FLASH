(globalThis["TURBOPACK_CHUNK_LISTS"] || (globalThis["TURBOPACK_CHUNK_LISTS"] = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: ["static/chunks/apps_website_src_0pa88xx._.css","static/chunks/06ln_next_0mcm1se._.js","static/chunks/0t0b_zod_0ujgiel._.js","static/chunks/node_modules__pnpm_0gf~xlo._.js","static/chunks/apps_website_src_0ycyrrp._.js"],
    source: "dynamic"
});
