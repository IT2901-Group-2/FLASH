(globalThis["TURBOPACK_CHUNK_LISTS"] || (globalThis["TURBOPACK_CHUNK_LISTS"] = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: ["static/chunks/apps_website_src_11b.084._.css","static/chunks/_0dxg55s._.js"],
    source: "dynamic"
});
