(globalThis["TURBOPACK"] || (globalThis["TURBOPACK"] = [])).push([typeof document === "object" ? document.currentScript : undefined,
"[project]/apps/website/src/app/[locale]/(sidebar)/admin/layout.module.css [app-client] (css module)", ((__turbopack_context__) => {

__turbopack_context__.v({
  "section": "layout-module__amvFHG__section",
});
}),
"[project]/apps/website/src/components/Headers/BaseHeader.module.css [app-client] (css module)", ((__turbopack_context__) => {

__turbopack_context__.v({
  "header": "BaseHeader-module__j3rQTa__header",
  "headerContent": "BaseHeader-module__j3rQTa__headerContent",
});
}),
"[project]/apps/website/src/components/Headers/BaseHeader.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$3_$40$babel$2b$core$40$7$2e$2_f73405d585fa6aff6e0e33dac278bfb2$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.2.3_@babel+core@7.2_f73405d585fa6aff6e0e33dac278bfb2/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$3_$40$babel$2b$core$40$7$2e$2_f73405d585fa6aff6e0e33dac278bfb2$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.2.3_@babel+core@7.2_f73405d585fa6aff6e0e33dac278bfb2/node_modules/next/dist/compiled/react/compiler-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$ui$2f$dist$2f$index$2e$es$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/ui/dist/index.es.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$website$2f$src$2f$components$2f$Headers$2f$BaseHeader$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__ = __turbopack_context__.i("[project]/apps/website/src/components/Headers/BaseHeader.module.css [app-client] (css module)");
var __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$website$2f$src$2f$hooks$2f$useIsMobile$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/apps/website/src/hooks/useIsMobile.ts [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
;
;
;
;
const BaseHeader = (t0)=>{
    _s();
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$3_$40$babel$2b$core$40$7$2e$2_f73405d585fa6aff6e0e33dac278bfb2$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(13);
    if ($[0] !== "1cb71d0d26135d477d380bd30c9fa88c5a5d0ba0a258264e8c7f544ac2b55885") {
        for(let $i = 0; $i < 13; $i += 1){
            $[$i] = Symbol.for("react.memo_cache_sentinel");
        }
        $[0] = "1cb71d0d26135d477d380bd30c9fa88c5a5d0ba0a258264e8c7f544ac2b55885";
    }
    let children;
    let props;
    let t1;
    if ($[1] !== t0) {
        ({ hideOnDesktop: t1, children, ...props } = t0);
        $[1] = t0;
        $[2] = children;
        $[3] = props;
        $[4] = t1;
    } else {
        children = $[2];
        props = $[3];
        t1 = $[4];
    }
    const hideOnDesktop = t1 === undefined ? false : t1;
    const isMobile = (0, __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$website$2f$src$2f$hooks$2f$useIsMobile$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])();
    if (hideOnDesktop && !isMobile) {
        return;
    }
    let t2;
    if ($[5] !== isMobile) {
        t2 = isMobile && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$3_$40$babel$2b$core$40$7$2e$2_f73405d585fa6aff6e0e33dac278bfb2$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$ui$2f$dist$2f$index$2e$es$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Sidebar"].Trigger, {}, void 0, false, {
            fileName: "[project]/apps/website/src/components/Headers/BaseHeader.tsx",
            lineNumber: 46,
            columnNumber: 22
        }, ("TURBOPACK compile-time value", void 0));
        $[5] = isMobile;
        $[6] = t2;
    } else {
        t2 = $[6];
    }
    let t3;
    if ($[7] !== children || $[8] !== props) {
        t3 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$3_$40$babel$2b$core$40$7$2e$2_f73405d585fa6aff6e0e33dac278bfb2$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            ...props,
            className: __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$website$2f$src$2f$components$2f$Headers$2f$BaseHeader$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].headerContent,
            children: children
        }, void 0, false, {
            fileName: "[project]/apps/website/src/components/Headers/BaseHeader.tsx",
            lineNumber: 54,
            columnNumber: 10
        }, ("TURBOPACK compile-time value", void 0));
        $[7] = children;
        $[8] = props;
        $[9] = t3;
    } else {
        t3 = $[9];
    }
    let t4;
    if ($[10] !== t2 || $[11] !== t3) {
        t4 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$3_$40$babel$2b$core$40$7$2e$2_f73405d585fa6aff6e0e33dac278bfb2$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("header", {
            className: __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$website$2f$src$2f$components$2f$Headers$2f$BaseHeader$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].header,
            children: [
                t2,
                t3
            ]
        }, void 0, true, {
            fileName: "[project]/apps/website/src/components/Headers/BaseHeader.tsx",
            lineNumber: 63,
            columnNumber: 10
        }, ("TURBOPACK compile-time value", void 0));
        $[10] = t2;
        $[11] = t3;
        $[12] = t4;
    } else {
        t4 = $[12];
    }
    return t4;
};
_s(BaseHeader, "zdJ8C3X+YlDYVai5EPOd8CzoqSU=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$website$2f$src$2f$hooks$2f$useIsMobile$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"]
    ];
});
_c = BaseHeader;
const __TURBOPACK__default__export__ = BaseHeader;
var _c;
__turbopack_context__.k.register(_c, "BaseHeader");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/apps/website/src/utils/className.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "cl",
    ()=>cl
]);
/**
 * Converts a value of type `ClassValue` into a space-separated string of class names.
 *
 * - If the input is `null`, `undefined`, or a boolean, returns an empty string.
 * - If the input is a string or number, returns its string representation.
 * - If the input is an array, recursively processes each element and joins the results with spaces.
 * - If the input is an object, includes the keys whose values are truthy, joined by spaces.
 *
 * @param mix - The value to convert to a class name string. Can be a string, number, array, or object.
 * @returns A space-separated string of class names.
 */ function toVal(mix) {
    let k, y, str = "";
    if (typeof mix === "string" || typeof mix === "number") {
        str += mix;
    } else if (typeof mix === "object") {
        if (Array.isArray(mix)) {
            const len = mix.length;
            for(k = 0; k < len; k++){
                if (mix[k]) {
                    if (y = toVal(mix[k])) {
                        if (str) str += " ";
                        str += y;
                    }
                }
            }
        } else {
            for(y in mix){
                if (mix[y]) {
                    if (str) str += " ";
                    str += y;
                }
            }
        }
    }
    return str;
}
function cl(...inputs) {
    let i = 0, tmp, x, str = "";
    const len = inputs.length;
    for(; i < len; i++){
        if (tmp = inputs[i]) {
            if (x = toVal(tmp)) {
                if (str) str += " ";
                str += x;
            }
        }
    }
    return str;
}
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/apps/website/src/components/Headers/ModerateHeader.module.css [app-client] (css module)", ((__turbopack_context__) => {

__turbopack_context__.v({
  "actionButton": "ModerateHeader-module__YYXpJW__actionButton",
  "backButton": "ModerateHeader-module__YYXpJW__backButton",
  "leftSection": "ModerateHeader-module__YYXpJW__leftSection",
  "rightSection": "ModerateHeader-module__YYXpJW__rightSection",
  "title": "ModerateHeader-module__YYXpJW__title",
  "titleSelectMode": "ModerateHeader-module__YYXpJW__titleSelectMode",
});
}),
"[project]/apps/website/src/components/Headers/ModerateHeader.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "ModerateHeader",
    ()=>ModerateHeader,
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$3_$40$babel$2b$core$40$7$2e$2_f73405d585fa6aff6e0e33dac278bfb2$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.2.3_@babel+core@7.2_f73405d585fa6aff6e0e33dac278bfb2/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$3_$40$babel$2b$core$40$7$2e$2_f73405d585fa6aff6e0e33dac278bfb2$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.2.3_@babel+core@7.2_f73405d585fa6aff6e0e33dac278bfb2/node_modules/next/dist/compiled/react/compiler-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$0$2e$562$2e$0_react$40$19$2e$2$2e$3$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$chevron$2d$left$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ChevronLeft$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/lucide-react@0.562.0_react@19.2.3/node_modules/lucide-react/dist/esm/icons/chevron-left.js [app-client] (ecmascript) <export default as ChevronLeft>");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$ui$2f$dist$2f$index$2e$es$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/ui/dist/index.es.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$2d$intl$40$4$2e$9$2e$1_next$40$16$2e$2$2e$3_ab90abf0e76369f02f5b4b6473e34bdc$2f$node_modules$2f$next$2d$intl$2f$dist$2f$esm$2f$development$2f$react$2d$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next-intl@4.9.1_next@16.2.3_ab90abf0e76369f02f5b4b6473e34bdc/node_modules/next-intl/dist/esm/development/react-client/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$website$2f$src$2f$utils$2f$className$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/apps/website/src/utils/className.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$website$2f$src$2f$components$2f$Headers$2f$ModerateHeader$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__ = __turbopack_context__.i("[project]/apps/website/src/components/Headers/ModerateHeader.module.css [app-client] (css module)");
var __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$website$2f$src$2f$components$2f$Headers$2f$BaseHeader$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/apps/website/src/components/Headers/BaseHeader.tsx [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
"use client";
;
;
;
;
;
;
;
const ModerateHeader = (t0)=>{
    _s();
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$3_$40$babel$2b$core$40$7$2e$2_f73405d585fa6aff6e0e33dac278bfb2$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(45);
    if ($[0] !== "2bcee791756f20d9c69ba6378187477637b11c32bb2682037bd4f9047c0a2f4c") {
        for(let $i = 0; $i < 45; $i += 1){
            $[$i] = Symbol.for("react.memo_cache_sentinel");
        }
        $[0] = "2bcee791756f20d9c69ba6378187477637b11c32bb2682037bd4f9047c0a2f4c";
    }
    let onBack;
    let onSelectAll;
    let onSelectToggle;
    let rest;
    let selectMode;
    let t1;
    if ($[1] !== t0) {
        ({ onBack, selectMode, onSelectToggle, onSelectAll, allSelected: t1, ...rest } = t0);
        $[1] = t0;
        $[2] = onBack;
        $[3] = onSelectAll;
        $[4] = onSelectToggle;
        $[5] = rest;
        $[6] = selectMode;
        $[7] = t1;
    } else {
        onBack = $[2];
        onSelectAll = $[3];
        onSelectToggle = $[4];
        rest = $[5];
        selectMode = $[6];
        t1 = $[7];
    }
    const allSelected = t1 === undefined ? false : t1;
    const t = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$2d$intl$40$4$2e$9$2e$1_next$40$16$2e$2$2e$3_ab90abf0e76369f02f5b4b6473e34bdc$2f$node_modules$2f$next$2d$intl$2f$dist$2f$esm$2f$development$2f$react$2d$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useTranslations"])("guest.event.moderate");
    let t2;
    if ($[8] !== allSelected || $[9] !== t) {
        t2 = allSelected ? t("actions.deselectAll") : t("actions.selectAll");
        $[8] = allSelected;
        $[9] = t;
        $[10] = t2;
    } else {
        t2 = $[10];
    }
    const selectAllLabel = t2;
    let t3;
    if ($[11] === Symbol.for("react.memo_cache_sentinel")) {
        t3 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$3_$40$babel$2b$core$40$7$2e$2_f73405d585fa6aff6e0e33dac278bfb2$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$0$2e$562$2e$0_react$40$19$2e$2$2e$3$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$chevron$2d$left$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ChevronLeft$3e$__["ChevronLeft"], {
            "aria-hidden": "true"
        }, void 0, false, {
            fileName: "[project]/apps/website/src/components/Headers/ModerateHeader.tsx",
            lineNumber: 69,
            columnNumber: 10
        }, ("TURBOPACK compile-time value", void 0));
        $[11] = t3;
    } else {
        t3 = $[11];
    }
    let t4;
    if ($[12] !== t) {
        t4 = t("aria.goBack");
        $[12] = t;
        $[13] = t4;
    } else {
        t4 = $[13];
    }
    let t5;
    if ($[14] !== onBack || $[15] !== t4) {
        t5 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$3_$40$babel$2b$core$40$7$2e$2_f73405d585fa6aff6e0e33dac278bfb2$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$ui$2f$dist$2f$index$2e$es$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Button"], {
            className: __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$website$2f$src$2f$components$2f$Headers$2f$ModerateHeader$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].backButton,
            variant: "tertiary",
            icon: t3,
            onClick: onBack,
            "aria-label": t4
        }, void 0, false, {
            fileName: "[project]/apps/website/src/components/Headers/ModerateHeader.tsx",
            lineNumber: 84,
            columnNumber: 10
        }, ("TURBOPACK compile-time value", void 0));
        $[14] = onBack;
        $[15] = t4;
        $[16] = t5;
    } else {
        t5 = $[16];
    }
    const t6 = selectMode && __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$website$2f$src$2f$components$2f$Headers$2f$ModerateHeader$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].titleSelectMode;
    let t7;
    if ($[17] !== t6) {
        t7 = (0, __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$website$2f$src$2f$utils$2f$className$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cl"])(__TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$website$2f$src$2f$components$2f$Headers$2f$ModerateHeader$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].title, t6);
        $[17] = t6;
        $[18] = t7;
    } else {
        t7 = $[18];
    }
    let t8;
    if ($[19] !== t) {
        t8 = t("title");
        $[19] = t;
        $[20] = t8;
    } else {
        t8 = $[20];
    }
    let t9;
    if ($[21] !== t7 || $[22] !== t8) {
        t9 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$3_$40$babel$2b$core$40$7$2e$2_f73405d585fa6aff6e0e33dac278bfb2$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$ui$2f$dist$2f$index$2e$es$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Title"], {
            as: "h1",
            size: "large",
            weight: "bold",
            className: t7,
            children: t8
        }, void 0, false, {
            fileName: "[project]/apps/website/src/components/Headers/ModerateHeader.tsx",
            lineNumber: 110,
            columnNumber: 10
        }, ("TURBOPACK compile-time value", void 0));
        $[21] = t7;
        $[22] = t8;
        $[23] = t9;
    } else {
        t9 = $[23];
    }
    let t10;
    if ($[24] !== t5 || $[25] !== t9) {
        t10 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$3_$40$babel$2b$core$40$7$2e$2_f73405d585fa6aff6e0e33dac278bfb2$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$website$2f$src$2f$components$2f$Headers$2f$ModerateHeader$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].leftSection,
            children: [
                t5,
                t9
            ]
        }, void 0, true, {
            fileName: "[project]/apps/website/src/components/Headers/ModerateHeader.tsx",
            lineNumber: 119,
            columnNumber: 11
        }, ("TURBOPACK compile-time value", void 0));
        $[24] = t5;
        $[25] = t9;
        $[26] = t10;
    } else {
        t10 = $[26];
    }
    let t11;
    if ($[27] !== onSelectAll || $[28] !== selectAllLabel || $[29] !== selectMode) {
        t11 = selectMode && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$3_$40$babel$2b$core$40$7$2e$2_f73405d585fa6aff6e0e33dac278bfb2$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$ui$2f$dist$2f$index$2e$es$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Button"], {
            variant: "primary",
            size: "medium",
            "data-color": "brand-purple",
            className: __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$website$2f$src$2f$components$2f$Headers$2f$ModerateHeader$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].actionButton,
            onClick: onSelectAll,
            children: selectAllLabel
        }, void 0, false, {
            fileName: "[project]/apps/website/src/components/Headers/ModerateHeader.tsx",
            lineNumber: 128,
            columnNumber: 25
        }, ("TURBOPACK compile-time value", void 0));
        $[27] = onSelectAll;
        $[28] = selectAllLabel;
        $[29] = selectMode;
        $[30] = t11;
    } else {
        t11 = $[30];
    }
    const t12 = selectMode ? "secondary" : "primary";
    let t13;
    if ($[31] !== selectMode || $[32] !== t) {
        t13 = selectMode ? t("actions.cancel") : t("actions.select");
        $[31] = selectMode;
        $[32] = t;
        $[33] = t13;
    } else {
        t13 = $[33];
    }
    let t14;
    if ($[34] !== onSelectToggle || $[35] !== t12 || $[36] !== t13) {
        t14 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$3_$40$babel$2b$core$40$7$2e$2_f73405d585fa6aff6e0e33dac278bfb2$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$ui$2f$dist$2f$index$2e$es$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Button"], {
            variant: t12,
            size: "medium",
            "data-color": "brand-purple",
            className: __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$website$2f$src$2f$components$2f$Headers$2f$ModerateHeader$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].actionButton,
            onClick: onSelectToggle,
            children: t13
        }, void 0, false, {
            fileName: "[project]/apps/website/src/components/Headers/ModerateHeader.tsx",
            lineNumber: 148,
            columnNumber: 11
        }, ("TURBOPACK compile-time value", void 0));
        $[34] = onSelectToggle;
        $[35] = t12;
        $[36] = t13;
        $[37] = t14;
    } else {
        t14 = $[37];
    }
    let t15;
    if ($[38] !== t11 || $[39] !== t14) {
        t15 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$3_$40$babel$2b$core$40$7$2e$2_f73405d585fa6aff6e0e33dac278bfb2$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$website$2f$src$2f$components$2f$Headers$2f$ModerateHeader$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].rightSection,
            children: [
                t11,
                t14
            ]
        }, void 0, true, {
            fileName: "[project]/apps/website/src/components/Headers/ModerateHeader.tsx",
            lineNumber: 158,
            columnNumber: 11
        }, ("TURBOPACK compile-time value", void 0));
        $[38] = t11;
        $[39] = t14;
        $[40] = t15;
    } else {
        t15 = $[40];
    }
    let t16;
    if ($[41] !== rest || $[42] !== t10 || $[43] !== t15) {
        t16 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$3_$40$babel$2b$core$40$7$2e$2_f73405d585fa6aff6e0e33dac278bfb2$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$website$2f$src$2f$components$2f$Headers$2f$BaseHeader$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            ...rest,
            children: [
                t10,
                t15
            ]
        }, void 0, true, {
            fileName: "[project]/apps/website/src/components/Headers/ModerateHeader.tsx",
            lineNumber: 167,
            columnNumber: 11
        }, ("TURBOPACK compile-time value", void 0));
        $[41] = rest;
        $[42] = t10;
        $[43] = t15;
        $[44] = t16;
    } else {
        t16 = $[44];
    }
    return t16;
};
_s(ModerateHeader, "h6+q2O3NJKPY5uL0BIJGLIanww8=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$2d$intl$40$4$2e$9$2e$1_next$40$16$2e$2$2e$3_ab90abf0e76369f02f5b4b6473e34bdc$2f$node_modules$2f$next$2d$intl$2f$dist$2f$esm$2f$development$2f$react$2d$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useTranslations"]
    ];
});
_c = ModerateHeader;
const __TURBOPACK__default__export__ = ModerateHeader;
var _c;
__turbopack_context__.k.register(_c, "ModerateHeader");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/apps/website/src/components/Headers/index.ts [app-client] (ecmascript) <locals>", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([]);
var __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$website$2f$src$2f$components$2f$Headers$2f$BaseHeader$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/apps/website/src/components/Headers/BaseHeader.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$website$2f$src$2f$components$2f$Headers$2f$ModerateHeader$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/apps/website/src/components/Headers/ModerateHeader.tsx [app-client] (ecmascript)");
;
;
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/apps/website/src/components/Headers/BaseHeader.tsx [app-client] (ecmascript) <export default as BaseHeader>", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "BaseHeader",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$website$2f$src$2f$components$2f$Headers$2f$BaseHeader$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"]
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$website$2f$src$2f$components$2f$Headers$2f$BaseHeader$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/apps/website/src/components/Headers/BaseHeader.tsx [app-client] (ecmascript)");
}),
"[project]/apps/website/src/app/[locale]/(sidebar)/admin/layout.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>Layout
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$3_$40$babel$2b$core$40$7$2e$2_f73405d585fa6aff6e0e33dac278bfb2$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.2.3_@babel+core@7.2_f73405d585fa6aff6e0e33dac278bfb2/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$3_$40$babel$2b$core$40$7$2e$2_f73405d585fa6aff6e0e33dac278bfb2$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.2.3_@babel+core@7.2_f73405d585fa6aff6e0e33dac278bfb2/node_modules/next/dist/compiled/react/compiler-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$website$2f$src$2f$app$2f5b$locale$5d2f28$sidebar$292f$admin$2f$layout$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__ = __turbopack_context__.i("[project]/apps/website/src/app/[locale]/(sidebar)/admin/layout.module.css [app-client] (css module)");
var __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$website$2f$src$2f$components$2f$Headers$2f$index$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/apps/website/src/components/Headers/index.ts [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$website$2f$src$2f$components$2f$Headers$2f$BaseHeader$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__BaseHeader$3e$__ = __turbopack_context__.i("[project]/apps/website/src/components/Headers/BaseHeader.tsx [app-client] (ecmascript) <export default as BaseHeader>");
"use client";
;
;
;
;
function Layout(t0) {
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$3_$40$babel$2b$core$40$7$2e$2_f73405d585fa6aff6e0e33dac278bfb2$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(4);
    if ($[0] !== "630cb680c7d2746c8a5b9a7338a963421c288a6a09ef730f6885bb52843931fd") {
        for(let $i = 0; $i < 4; $i += 1){
            $[$i] = Symbol.for("react.memo_cache_sentinel");
        }
        $[0] = "630cb680c7d2746c8a5b9a7338a963421c288a6a09ef730f6885bb52843931fd";
    }
    const { children } = t0;
    let t1;
    if ($[1] === Symbol.for("react.memo_cache_sentinel")) {
        t1 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$3_$40$babel$2b$core$40$7$2e$2_f73405d585fa6aff6e0e33dac278bfb2$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$website$2f$src$2f$components$2f$Headers$2f$BaseHeader$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__BaseHeader$3e$__["BaseHeader"], {
            hideOnDesktop: true
        }, void 0, false, {
            fileName: "[project]/apps/website/src/app/[locale]/(sidebar)/admin/layout.tsx",
            lineNumber: 19,
            columnNumber: 10
        }, this);
        $[1] = t1;
    } else {
        t1 = $[1];
    }
    let t2;
    if ($[2] !== children) {
        t2 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$3_$40$babel$2b$core$40$7$2e$2_f73405d585fa6aff6e0e33dac278bfb2$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$3_$40$babel$2b$core$40$7$2e$2_f73405d585fa6aff6e0e33dac278bfb2$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
            children: [
                t1,
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$2$2e$3_$40$babel$2b$core$40$7$2e$2_f73405d585fa6aff6e0e33dac278bfb2$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("section", {
                    className: __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$website$2f$src$2f$app$2f5b$locale$5d2f28$sidebar$292f$admin$2f$layout$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].section,
                    children: children
                }, void 0, false, {
                    fileName: "[project]/apps/website/src/app/[locale]/(sidebar)/admin/layout.tsx",
                    lineNumber: 26,
                    columnNumber: 16
                }, this)
            ]
        }, void 0, true);
        $[2] = children;
        $[3] = t2;
    } else {
        t2 = $[3];
    }
    return t2;
}
_c = Layout;
var _c;
__turbopack_context__.k.register(_c, "Layout");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/node_modules/.pnpm/lucide-react@0.562.0_react@19.2.3/node_modules/lucide-react/dist/esm/icons/chevron-left.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "__iconNode",
    ()=>__iconNode,
    "default",
    ()=>ChevronLeft
]);
/**
 * @license lucide-react v0.562.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */ var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$0$2e$562$2e$0_react$40$19$2e$2$2e$3$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$createLucideIcon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/lucide-react@0.562.0_react@19.2.3/node_modules/lucide-react/dist/esm/createLucideIcon.js [app-client] (ecmascript)");
;
const __iconNode = [
    [
        "path",
        {
            d: "m15 18-6-6 6-6",
            key: "1wnfg3"
        }
    ]
];
const ChevronLeft = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$0$2e$562$2e$0_react$40$19$2e$2$2e$3$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$createLucideIcon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])("chevron-left", __iconNode);
;
}),
"[project]/node_modules/.pnpm/lucide-react@0.562.0_react@19.2.3/node_modules/lucide-react/dist/esm/icons/chevron-left.js [app-client] (ecmascript) <export default as ChevronLeft>", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "ChevronLeft",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$0$2e$562$2e$0_react$40$19$2e$2$2e$3$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$chevron$2d$left$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"]
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$lucide$2d$react$40$0$2e$562$2e$0_react$40$19$2e$2$2e$3$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$chevron$2d$left$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/lucide-react@0.562.0_react@19.2.3/node_modules/lucide-react/dist/esm/icons/chevron-left.js [app-client] (ecmascript)");
}),
]);

//# sourceMappingURL=_0dxg55s._.js.map