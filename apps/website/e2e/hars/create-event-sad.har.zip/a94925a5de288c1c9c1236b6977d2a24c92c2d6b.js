(globalThis["TURBOPACK_CHUNK_LISTS"] || (globalThis["TURBOPACK_CHUNK_LISTS"] = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: ["static/chunks/apps_website_src_0--_gcg._.js","static/chunks/06ln_next_0.0_n-x._.js","static/chunks/0t0b_zod_0ujgiel._.js","static/chunks/0w30_drizzle-orm_0mkwks_._.js","static/chunks/0b2k_webrtc-adapter_src_js_0tkkibe._.js","static/chunks/node_modules__pnpm_03lbvfm._.js","static/chunks/apps_website_src_0z880pe._.css"],
    source: "dynamic"
});
