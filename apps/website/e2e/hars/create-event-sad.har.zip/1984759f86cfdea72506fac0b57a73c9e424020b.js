(globalThis["TURBOPACK_CHUNK_LISTS"] || (globalThis["TURBOPACK_CHUNK_LISTS"] = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: ["static/chunks/apps_website_src_0wha_r3._.js","static/chunks/06ln_next_0ktg0na._.js","static/chunks/0t0b_zod_0ujgiel._.js","static/chunks/0w30_drizzle-orm_0mkwks_._.js","static/chunks/node_modules__pnpm_037yzpn._.js","static/chunks/apps_website_src_0cxg_tt._.css"],
    source: "dynamic"
});
