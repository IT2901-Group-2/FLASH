(globalThis["TURBOPACK_CHUNK_LISTS"] || (globalThis["TURBOPACK_CHUNK_LISTS"] = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: ["static/chunks/apps_website_src_0_2bqyr._.js","static/chunks/node_modules__pnpm_0bah.fp._.js","static/chunks/apps_website_src_026ynfn._.css"],
    source: "dynamic"
});
