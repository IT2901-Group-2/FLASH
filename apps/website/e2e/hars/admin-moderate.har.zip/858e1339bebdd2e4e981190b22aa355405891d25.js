(globalThis["TURBOPACK_CHUNK_LISTS"] || (globalThis["TURBOPACK_CHUNK_LISTS"] = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: ["static/chunks/apps_website_src_0fx1jm2._.js","static/chunks/node_modules__pnpm_04f0xf.._.js","static/chunks/apps_website_src_0ybxhy_._.css"],
    source: "dynamic"
});
