(globalThis["TURBOPACK_CHUNK_LISTS"] || (globalThis["TURBOPACK_CHUNK_LISTS"] = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: ["static/chunks/apps_website_src_0ksfjzq._.js","static/chunks/node_modules__pnpm_0~oki--._.js","static/chunks/apps_website_src_0vy320e._.css"],
    source: "dynamic"
});
