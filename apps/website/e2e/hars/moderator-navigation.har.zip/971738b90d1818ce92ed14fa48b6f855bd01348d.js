(globalThis["TURBOPACK_CHUNK_LISTS"] || (globalThis["TURBOPACK_CHUNK_LISTS"] = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: ["static/chunks/_0q_10~s._.js","static/chunks/node_modules__pnpm_0agqi2w._.js","static/chunks/[root-of-the-server]__06hx~jc._.css"],
    source: "dynamic"
});
