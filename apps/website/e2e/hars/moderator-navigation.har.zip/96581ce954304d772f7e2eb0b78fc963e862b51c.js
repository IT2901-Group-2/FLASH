(globalThis["TURBOPACK_CHUNK_LISTS"] || (globalThis["TURBOPACK_CHUNK_LISTS"] = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: ["static/chunks/apps_website_src_0m81tzu._.js","static/chunks/node_modules__pnpm_0f1_8yw._.js","static/chunks/apps_website_src_0bd9lkv._.css"],
    source: "dynamic"
});
