(globalThis["TURBOPACK_CHUNK_LISTS"] || (globalThis["TURBOPACK_CHUNK_LISTS"] = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: ["static/chunks/apps_website_src_app_[locale]_events_[id]_moderate_layout_module_0tjqxtl.css","static/chunks/apps_website_src_app_[locale]_events_[id]_moderate_0~9n36d._.js"],
    source: "dynamic"
});
